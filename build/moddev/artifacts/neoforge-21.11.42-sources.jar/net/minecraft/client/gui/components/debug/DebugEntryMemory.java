package net.minecraft.client.gui.components.debug;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import net.minecraft.resources.Identifier;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.chunk.LevelChunk;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.api.distmarker.OnlyIn;
import org.jspecify.annotations.Nullable;

@OnlyIn(Dist.CLIENT)
public class DebugEntryMemory implements DebugScreenEntry {
    public static final Identifier GROUP = Identifier.withDefaultNamespace("memory");
    private final DebugEntryMemory.AllocationRateCalculator allocationRateCalculator = new DebugEntryMemory.AllocationRateCalculator();

    @Override
    public void display(DebugScreenDisplayer p_434950_, @Nullable Level p_433557_, @Nullable LevelChunk p_433131_, @Nullable LevelChunk p_435112_) {
        long i = Runtime.getRuntime().maxMemory();
        long j = Runtime.getRuntime().totalMemory();
        long k = Runtime.getRuntime().freeMemory();
        long l = j - k;
        p_434950_.addToGroup(
            GROUP,
            List.of(
                String.format(Locale.ROOT, "Mem: %2d%% %03d/%03dMB", l * 100L / i, bytesToMegabytes(l), bytesToMegabytes(i)),
                String.format(Locale.ROOT, "Allocation rate: %03dMB/s", bytesToMegabytes(this.allocationRateCalculator.bytesAllocatedPerSecond(l))),
                String.format(Locale.ROOT, "Allocated: %2d%% %03dMB", j * 100L / i, bytesToMegabytes(j))
            )
        );
    }

    private static long bytesToMegabytes(long p_434765_) {
        return p_434765_ / 1024L / 1024L;
    }

    @Override
    public boolean isAllowed(boolean p_433579_) {
        return true;
    }

    @OnlyIn(Dist.CLIENT)
    static class AllocationRateCalculator {
        private static final int UPDATE_INTERVAL_MS = 500;
        private static final List<GarbageCollectorMXBean> GC_MBEANS = ManagementFactory.getGarbageCollectorMXBeans();
        private long lastTime = 0L;
        private long lastHeapUsage = -1L;
        private long lastGcCounts = -1L;
        private long lastRate = 0L;

        long bytesAllocatedPerSecond(long p_433179_) {
            long i = System.currentTimeMillis();
            if (i - this.lastTime < 500L) {
                return this.lastRate;
            } else {
                long j = gcCounts();
                if (this.lastTime != 0L && j == this.lastGcCounts) {
                    double d0 = (double)TimeUnit.SECONDS.toMillis(1L) / (i - this.lastTime);
                    long k = p_433179_ - this.lastHeapUsage;
                    this.lastRate = Math.round(k * d0);
                }

                this.lastTime = i;
                this.lastHeapUsage = p_433179_;
                this.lastGcCounts = j;
                return this.lastRate;
            }
        }

        private static long gcCounts() {
            long i = 0L;

            for (GarbageCollectorMXBean garbagecollectormxbean : GC_MBEANS) {
                i += garbagecollectormxbean.getCollectionCount();
            }

            return i;
        }
    }
}
